/*********************************************
 * Description - Seraphim, Baremetal x86
 * topdown shooter
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/

asm (".code16gcc\n"
    "call  dosmain\n"
    "mov   $0x4C,%ah\n"
    "int   $0x21\n");

/*********************************************
 * Description - Put string text
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Puts(char *string){
  asm volatile ("mov   $0x09, %%ah\n"
      "int   $0x21\n"
      : /* no output */
      : "d"(string)
      : "ah");
}

/*********************************************
 * Description - Start the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static int Beep(int freq){
  /*"mov     $0xb6,%al\n"*/
  asm volatile ( 
      "and     $0xfffe,%ax\n"
      "push    %ax\n"
      "cli\n"
      "mov     $0,%ax\n"
      "mov     $0xb6,%al\n"
      "out     %al,$0x43\n"
      "pop     %ax\n"
      "out     %al,$0x42\n"
      "mov     %ah,%al\n"
      "out     %al,$0x42\n"
      "in      $0x61, %al\n"
      "mov     %ah,%al\n"
      "or      $3,%al\n"
      "out     %al,$0x61\n"
      "sti\n" );
}

/*********************************************
 * Description - Stop the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void BeepOff(void){
  asm volatile("in      $0x61,%al\n"
      "and     $0xfc,%al\n"
      "out     %al,$0x61\n"
      );
}

/*********************************************
 * Description - Clear the screen in text mode,
 * then move the cursor to the top right
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void TextClear(void){
  /*Clear the screen*/
  asm volatile("mov $0x06,%ah\n"
      "mov $0,%al\n"
      "mov $0x07,%bh\n"
      "mov $0,%cx\n"
      "mov $0x184F,%dx\n"
      "int $0x10\n"

      /*Set the cursor to the top left*/
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}

/*********************************************
 * Description - Sleep for an amount of time
 * just does lots o halt
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Sleep(int time){
  for(time != 0;time--;){
    asm volatile("hlt");
  }
}

/*********************************************
 * Description - Turn on VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Vga(void){
  asm volatile(
      "mov $0x13,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Turn off VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void VgaOff(void){
  asm volatile(
      "mov $0x0003,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Plot a pixel in VGA
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void VgaPutPx(int x, int y, unsigned char vgacol){
  /*unsigned char* location = (unsigned char*)0xA0000 + 320 * y + x;*/
  unsigned char* location = (unsigned char*)0x9F000 + 320 * y + x;
  *location = vgacol;
}

/*********************************************
 * Description - Shut the machine down via 
 * reset vector
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Shutdown(void){
  asm volatile("jmp 0xFFF");
}

/*********************************************
 * Description - Get a key press
 * similar to https://www.phanderson.com/C/getkey.html
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
int GetKey(void){
  char c;
  asm volatile (
      "mov $0, %%eax\n"
      "mov $0x08, %%ah\n"
      "int $0x21\n"
      "mov %%al, %0\n"
      : "=r" (c)
      :
      : "%eax"
      );
  return c;
}

/*********************************************
 * Description - Wipe the VGA screen
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
void VgaClear(int col){
  /*unsigned char* location = (unsigned char*)0x9EF00;*/
  unsigned char* location = (unsigned char*)0xA000;
  for((unsigned char*)location != 
      /*(unsigned char*)0x9F000+(320*200);location++;){*/
    (unsigned char*)0xBFFFF;location++;){
      *location = col;
    }
}

/*********************************************
 * Description - Our Oracle
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
int GetOracle(void){
  int oracle;
  asm volatile (
      "rdtsc\n"
      "mov %%eax, %0\n"
      : "=r" (oracle)
      :
      : "%eax"
      );
  /*
     asm volatile (
     "rdtsc\n"
     "rdseed %%ebx\n"
     "add %%ebx,%%eax\n"
     "mov %%eax, %0\n"
     : "=r" (oracle)
     :
     : "%eax"
     );
     */
  return oracle;
  /*return ((oracle)%(start,end))+end;*/
}

/*********************************************
 * Description - Convert integers into strings
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
char* Int2Str(int num, char* string){

  if(num == 0){
    *string = '0';
    *(string+1) = 0;
    return string;
  }

  char* start = string;
  if(num < 0 ){
    *start = '-';
    num *= -1;
    start++;
  }

  while(num > 0 ){
    *start = '0' + num % 10;
    num /= 10;
    start++;
  }

  *start = 0;

  char* end = start - 1;
  start = string + (*string == '-');

  while(end > start ){
    char t = *start;
    *start = *end;
    *end = t;

    start++;
    end--;
  }

  return string;

}

/*********************************************
 * Description - Main
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
int dosmain(void){
  TextClear();
  Vga();
  Puts("Hello$");

  VgaClear(3);
  Shutdown();
  while(1){
    Puts("Hello$");
    char oraclestr[32]; 
    oraclestr[31] = '\n';
    oraclestr[32] = '$';
    Int2Str(GetOracle(),oraclestr);
    Puts(oraclestr);
  }

  return 0;
}
