#!/bin/sh
gcc -std=gnu99 -m32 -march=i386 -fno-PIC -nostdlib -ffreestanding \
-o dos.com -Wl,--nmagic,--script=com.ld main.c && dosbox dos.com
