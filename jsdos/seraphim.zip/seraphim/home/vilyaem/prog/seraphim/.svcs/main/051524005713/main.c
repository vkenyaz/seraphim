/*********************************************
 * Description - Seraphim, Baremetal x86
 * topdown shooter
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/

asm (".code16gcc\n"
    "call  dosmain\n"
    "mov   $0x4C,%ah\n"
    "int   $0x21\n");

/*----------PREPROCESSOR----------*/

#define VGA_MEM 0x9E6E0


/*----------GLOBALS----------*/

int i;

/*----------FUNCTIONS----------*/

/*********************************************
 * Description - Outb, write byte to IO port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline void outb(int port, unsigned char value) {
  asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

/*********************************************
 * Description - Inb, read a byte from IO port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline unsigned char inb(int port) {
  unsigned char value;
  asm volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
  return value;
}

/*********************************************
 * Description - Put string text
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Puts(char *string){
  asm volatile ("mov   $0x09, %%ah\n"
      "int   $0x21\n"
      : /* no output */
      : "d"(string)
      : "ah");
}

/*********************************************
 * Description - Start the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static int Beep(unsigned char freq){
  /*"mov     $0xb6,%al\n"*/
  /*asm volatile( */
  /*
     "and     $0xfffe,%%ax\n"
     "push    %%ax\n"
     "cli\n"
     "mov     $0,%%ax\n"
     "mov     %1,%%al\n"
     "out     %%a1,$0x43\n"
     "pop     %%ax\n"
     "out     %%al,$0x42\n"
     "mov     %%ah,%%al\n"
     "out     %%al,$0x42\n"
     "in      $0x61, %%al\n"
     "mov     %%ah,%%al\n"
     "or      $3,%%al\n"
     "out     %%al,$0x61\n"
     "sti\n"
     */
  /*
     "mov $0xb6,%%al\n"
     "out %%al,$0x43\n"
     "out %%al,$0x42\n"
     "in $0x61,%%al\n"
     "mov %%ah,%%al\n"
     "or $3,%%al\n"
     "out %%al,$0x61\n"
     : 
     : "r" (freq)
     :
     );
     */

  int Div;
  unsigned char tmp;

  //Set the PIT to the desired frequency
  Div = 1193180 / freq;
  outb(0x43, 0xb6);
  outb(0x42, (unsigned char) (Div) );
  outb(0x42, (unsigned char) (Div >> 8));

  //And play the sound using the PC speaker
  tmp = inb(0x61);
  if (tmp != (tmp | 3)) {
    outb(0x61, tmp | 3);
  }

}

/*********************************************
 * Description - Stop the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void BeepOff(void){
  asm volatile("in      $0x61,%al\n"
      "and     $0xfc,%al\n"
      "out     %al,$0x61\n"
      );
}

/*********************************************
 * Description - Clear the screen in text mode,
 * then move the cursor to the top right
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void TextClear(void){
  /*Clear the screen*/
  asm volatile("mov $0x06,%ah\n"
      "mov $0,%al\n"
      "mov $0x07,%bh\n"
      "mov $0,%cx\n"
      "mov $0x184F,%dx\n"
      "int $0x10\n"

      /*Set the cursor to the top left*/
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}

/*********************************************
 * Description - Set Text Cursor Position
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static void SetCursorPos(int x, int y){

  /*Set X*/
  asm volatile(
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );

  /*Set Y and call interrupt*/
  asm volatile(
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}


/*********************************************
 * Description - Sleep for an amount of time
 * just does lots o halt
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Sleep(int time){
  for(time != 0;time--;){
    asm volatile("hlt");
  }
}

/*********************************************
 * Description - Turn on VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Vga(void){
  asm volatile(
      "mov $0x13,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Turn off VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void VgaOff(void){
  asm volatile(
      "mov $0x0003,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Plot a pixel in VGA
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void VgaPutPx(int x, int y, unsigned char vgacol){
  unsigned char* location = (unsigned char*)VGA_MEM + 320 * y + x;
  *location = vgacol;
}

/*********************************************
 * Description - Shut the machine down via 
 * reset vector or triple fault
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Shutdown(void){
  asm volatile("jmp 0xFFFF");
}

/*********************************************
 * Description - Get a key press
 * similar to https://www.phanderson.com/C/getkey.html
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static int GetKey(void){
  char c;
  asm volatile (
      "mov $0, %%eax\n"
      "mov $0x08, %%ah\n"
      "int $0x21\n"
      "mov %%al, %0\n"
      : "=r" (c)
      :
      : "%eax"
      );
  return c;
}

/*********************************************
 * Description - Wipe the VGA screen
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static void VgaClear(int col){
  /*
     unsigned char* location = (unsigned char*)0xA000;
     for((unsigned char*)location != 
     (unsigned char*)0xA000+320*200+320;location++;){
   *location = col;
   }
   */
  int x = 0;
  int y = 0;
  for(y = 0; y != 200;y++){
    for(x = 0; x != 320;x++){
      VgaPutPx(x,y,col);
    }
  }

}

/*********************************************
 * Description - Our Oracle
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static int GetOracle(void){
  int oracle;
  asm volatile (
      "rdtsc\n"
      "mov %%eax, %0\n"
      : "=r" (oracle)
      :
      : "%eax"
      );
  return oracle;
}

/*********************************************
 * Description - Convert integers into strings
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static char* Int2Str(int num, char* string){

  if(num == 0){
    *string = '0';
    *(string+1) = 0;
    return string;
  }

  char* start = string;
  if(num < 0 ){
    *start = '-';
    num *= -1;
    start++;
  }

  while(num > 0 ){
    *start = '0' + num % 10;
    num /= 10;
    start++;
  }

  *start = 0;

  char* end = start - 1;
  start = string + (*string == '-');

  while(end > start ){
    char t = *start;
    *start = *end;
    *end = t;

    start++;
    end--;
  }

  return string;

}

/*********************************************
 * Description - Main
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
int dosmain(void){
  Vga();
  Puts("Hello$");
  while(1){
    int bench = GetOracle();

    VgaClear(3);

    Beep(50);

    char oraclestr[32]; 
    oraclestr[31] = '\n';
    oraclestr[32] = '$';
    Int2Str(GetOracle()-bench,oraclestr);
    Puts(oraclestr);

    /*Sleep(3);*/
  }

  return 0;
}
