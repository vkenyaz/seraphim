/*********************************************
 * Description - Seraphim, Baremetal x86
 * topdown shooter
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/

asm (".code16gcc\n"
    "call  dosmain\n"
    "mov   $0x4C,%ah\n"
    "int   $0x21\n");

/*----------PREPROCESSOR----------*/

#define COM1_PORT 0x3F8
#define VGA_MEM 0x9E6E0


/*----------GLOBALS----------*/

int i;

/*----------FUNCTIONS----------*/

/*********************************************
 * Description - Outb, write byte to IO port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline void outb(int port, unsigned char value) {
  asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

/*********************************************
 * Description - Inb, read a byte from IO port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline unsigned char inb(int port) {
  unsigned char value;
  asm volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
  return value;
}

/*********************************************
 * Description - Put string text
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Puts(char *string){
  asm volatile ("mov   $0x09, %%ah\n"
      "int   $0x21\n"
      : /* no output */
      : "d"(string)
      : "ah");
}

/*********************************************
 * Description - Start the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static int Beep(unsigned char freq){
  int div;
  unsigned char tmp;

  /*Set the PIT to the desired frequency*/
  div = 1193180 / freq;
  outb(0x43, 0xb6);
  outb(0x42, (unsigned char) (div) );
  outb(0x42, (unsigned char) (div >> 8));

  /*And play the sound using the PC speaker*/
  tmp = inb(0x61);
  if (tmp != (tmp | 3)) {
    outb(0x61, tmp | 3);
  }

}

/*********************************************
 * Description - Stop the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void BeepOff(void){
  asm volatile("in      $0x61,%al\n"
      "and     $0xfc,%al\n"
      "out     %al,$0x61\n"
      );
}

/*********************************************
 * Description - Clear the screen in text mode,
 * then move the cursor to the top right
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void TextClear(void){
  /*Clear the screen*/
  asm volatile("mov $0x06,%ah\n"
      "mov $0,%al\n"
      "mov $0x07,%bh\n"
      "mov $0,%cx\n"
      "mov $0x184F,%dx\n"
      "int $0x10\n"

      /*Set the cursor to the top left*/
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}

/*********************************************
 * Description - Set Text Cursor Position
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static void SetCursorPos(int x, int y){

  /*Set X*/
  asm volatile(
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );

  /*Set Y and call interrupt*/
  asm volatile(
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}


/*********************************************
 * Description - Sleep for an amount of time
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Sleep(int time){
  /*
     unsigned char  current_count, target_count;

     outb(0x43, 0);  // Mode register for PIT Channel 0
     current_count = inb(0x40);

  // Calculate the target count based on required ticks
  target_count = current_count + time;

  // Wait until the required number of ticks have passed
  while (inb(0x40) != target_count) {
  // wait
  }
  */
  for(time != 0;time--;){
    asm volatile("hlt");
  }
}

/*********************************************
 * Description - Turn on VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Vga(void){
  asm volatile(
      "mov $0x13,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Turn off VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void VgaOff(void){
  asm volatile(
      "mov $0x0003,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Plot a pixel in VGA
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void VgaPutPx(int x, int y, unsigned char vgacol){
  unsigned char* location = (unsigned char*)VGA_MEM + 320 * y + x;
  *location = vgacol;
}

/*********************************************
 * Description - Shut the machine down via 
 * reset vector or triple fault
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static void Shutdown(void){
  asm volatile("jmp 0xFFFF");
}

/*********************************************
 * Description - Get a key press
 * similar to https://www.phanderson.com/C/getkey.html
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static int GetKey(void){
  char c;
  asm volatile (
      "mov $0, %%eax\n"
      "mov $0x08, %%ah\n"
      "int $0x21\n"
      "mov %%al, %0\n"
      : "=r" (c)
      :
      : "%eax"
      );
  return c;
}

/*********************************************
 * Description - Wipe the VGA screen
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static void VgaClear(int col){
  unsigned char* loc = (unsigned char*)VGA_MEM;
  for((unsigned char*)loc != (unsigned char*)VGA_MEM+320*200;loc++;){
    *loc=col;
  }
}

/*********************************************
 * Description - Our Oracle
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static int GetOracle(void){
  int oracle;
  asm volatile (
      "rdtsc\n"
      "mov %%eax, %0\n"
      : "=r" (oracle)
      :
      : "%eax"
      );
  return oracle;
}

/*********************************************
 * Description - Convert integers into strings
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static char* Int2Str(int num, char* string){

  if(num == 0){
    *string = '0';
    *(string+1) = 0;
    return string;
  }

  char* start = string;
  if(num < 0 ){
    *start = '-';
    num *= -1;
    start++;
  }

  while(num > 0 ){
    *start = '0' + num % 10;
    num /= 10;
    start++;
  }

  *start = 0;

  char* end = start - 1;
  start = string + (*string == '-');

  while(end > start ){
    char t = *start;
    *start = *end;
    *end = t;

    start++;
    end--;
  }

  return string;

}

/*********************************************
* Description - Output data to serial port
* Author - Vilyaem
* Date - May 15 2024
* *******************************************/
static void SerialWrite(unsigned short port, unsigned char data) {
  /*asm volatile("outb %0, %1" : : "a"(data), "Nd"(port));*/
  outb(port,data);
}

/*********************************************
* Description - Output text to serial port
* Author - Vilyaem
* Date - May 15 2024
* *******************************************/
static void SerialPuts(char* msg){
  for(i = 0; msg[i] != 0;i++) {
    SerialWrite(COM1_PORT, msg[i]);
    Puts(msg);
  }
}

/*********************************************
 * Description - Main
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
int dosmain(void){
  Vga();
  Puts("test$");
  SerialPuts("Hello Serial!");
  while(1){
    int bench = GetOracle();

    VgaClear(3);

    for(i = 0; i != 1024;i++){
      BeepOff();
      Beep(i&i>>8);
      Sleep(1);
    }

    char oraclestr[32]; 
    oraclestr[31] = '\n';
    oraclestr[32] = '$';
    Int2Str(GetOracle()-bench,oraclestr);
    Puts(oraclestr);
  }

  return 0;
}

