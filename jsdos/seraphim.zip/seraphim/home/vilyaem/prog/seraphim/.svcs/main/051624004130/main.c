/*********************************************
 * Description - Seraphim, Baremetal x86
 * topdown shooter
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/

asm (".code16gcc\n"
    "call  dosmain\n"
    "mov   $0x4C,%ah\n"
    "int   $0x21\n");

/*----------PREPROCESSOR----------*/

#define COM1_PORT 0x3F8
#define VGA_RESX 320
#define VGA_RESY 200
#define VGA_MEM 0x9E6E0
#define VGA_END VGA_MEM+VGA_RESX*VGA_RESY
#define FB_MEM VGA_END+500 /*Framebuffer location*/
#define FB_END FB_MEM+VGA_RESX*VGA_RESY
#define FG_COL 0
#define BG_COL 15

/*monochromatic graphics*/
#include "seraph.xbm"
#include "dmn.xbm"

/*Typedef sucks*/
typedef char i8;
typedef int i16;
typedef unsigned char u8;
typedef unsigned int u16;
typedef void vo;


/*----------GLOBALS----------*/

/*u8 frame = 0;*/
u8 fb[VGA_RESY][VGA_RESX];
i16 i;

/*----------FUNCTIONS----------*/

/*********************************************
 * Description - Call an x86 interrupt
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline vo int86(u8 interrupt){
  asm volatile ("int %0" : : "Nd"(interrupt));
}

/*********************************************
 * Description - Outb, write byte to IO port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline vo outb(i16 port, u8 value){
  asm volatile ("outb %0, %1" : : "a"(value), "Nd"(port));
}

/*********************************************
 * Description - Inb, read a byte from IO port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static inline u8 inb(i16 port){
  u8 value;
  asm volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
  return value;
}

/*********************************************
 * Description - Put string text
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo Puts(i8 *string){
  asm volatile ("mov $0xe0,%%bl\n"
      "mov   $0x09, %%ah\n"
      "int   $0x21\n"
      : /* no output */
      : "d"(string)
      : "ah");
}

/*********************************************
 * Description - Start the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static i16 Beep(i16 freq){
  i16 div;
  u8 tmp;

  /*Set the PIT to the desired frequency*/
  div = 1193180 / (u8)freq;
  outb(0x43, 0xb6);
  outb(0x42, (u8) (div) );
  outb(0x42, (u8) (div >> 8));

  /*And play the sound using the PC speaker*/
  tmp = inb(0x61);
  if (tmp != (tmp | 3)) {
    outb(0x61, tmp | 3);
  }
}

/*********************************************
 * Description - Stop the PC Speaker
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo BeepOff(vo){
  asm volatile("in      $0x61,%al\n"
      "and     $0xfc,%al\n"
      "out     %al,$0x61\n"
      );
}

/*********************************************
 * Description - Clear the screen in text mode,
 * then move the cursor to the top right
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo TextClear(vo){
  /*Clear the screen*/
  asm volatile("mov $0x06,%ah\n"
      "mov $0,%al\n"
      "mov $0x07,%bh\n"
      "mov $0,%cx\n"
      "mov $0x184F,%dx\n"
      "int $0x10\n"

      /*Set the cursor to the top left*/
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}

/*********************************************
 * Description - Set Text Cursor Position
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static vo SetCursorPos(i16 x, i16 y){
  /*Set X*/
  asm volatile(
      "mov $0x02,%ah\n"
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );

  /*Set Y and call i16errupt*/
  asm volatile(
      "mov $0x00,%bh\n"
      "mov $0x00,%dh\n"
      "mov $0x00,%dl\n" 
      "int $0x10\n"     
      );
}

/*********************************************
 * Description - Set text colours
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo SetTextColour(i16 fg, i16 bg){
}

/*********************************************
 * Description - Sleep for an amount of time
 *
 * 1000 is one second
 *
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo Sleep(i16 time){
  i16 waittime = 500*(time/1000);
  for(i = 0; i != waittime;i++){
    u8  current_count, target_count;
    outb(0x43, 0);  /* Mode register for PIT Channel 0*/
    current_count = inb(0x40);
    /* Calculate the target count based on required ticks*/
    target_count = current_count + time;
    /* Wait until the required number of ticks have passed*/
    while (inb(0x40) != target_count) {
    }
  }
}

/*********************************************
 * Description - Turn on VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo Vga(vo){
  asm volatile(
      "mov $0x13,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Turn off VGA mode
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo VgaOff(vo){
  asm volatile(
      "mov $0x0003,%ax\n"
      "int $0x10\n"
      );
}

/*********************************************
 * Description - Plot a pixel in VGA
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo VgaPutPx(i16 x, i16 y, u8 vgacol){
  u8* location = (u8*)VGA_MEM + VGA_RESX * y + x;
  *location = vgacol;
}

/*********************************************
 * Description - Shut the machine down via 
 * reset vector or triple fault
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
static vo Shutdown(vo){
  asm volatile("jmp 0xFFFF");
}

/*********************************************
 * Description - Get a key press
 * similar to https://www.phanderson.com/C/getkey.html
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static i16 GetKey(vo){
  i8 c;
  asm volatile (
      "mov $0, %%eax\n"
      "mov $0x08, %%ah\n"
      "int $0x21\n"
      "mov %%al, %0\n"
      : "=r" (c)
      :
      : "%eax"
      );
  return c;
}

/*********************************************
 * Description - Wipe the VGA screen
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static vo VgaClear(i16 col){
  u8* loc = (u8*)VGA_MEM;
  u8* dest = (u8*)VGA_MEMEND;
  while((u8*)loc != (u8*)dest){
    *loc=col;
    loc++;
  }
}

/*********************************************
 * Description - Our Oracle
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static i16 GetOracle(vo){
  u16 oracle;
  __asm__ volatile("rdtsc\nmov %%eax,%0" : "=a" (oracle));
  return oracle;
}

/*********************************************
 * Description - Convert i16egers into strings
 * Author - Vilyaem
 * Date - May 14 2024
 * *******************************************/
static i8* Int2Str(i16 num, i8* string){

  if(num == 0){
    *string = '0';
    *(string+1) = 0;
    return string;
  }

  i8* start = string;
  if(num < 0 ){
    *start = '-';
    num *= -1;
    start++;
  }

  while(num > 0 ){
    *start = '0' + num % 10;
    num /= 10;
    start++;
  }

  *start = 0;

  i8* end = start - 1;
  start = string + (*string == '-');

  while(end > start ){
    i8 t = *start;
    *start = *end;
    *end = t;

    start++;
    end--;
  }

  return string;

}

/*********************************************
 * Description - Output data to serial port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo SerialWrite(u8 data) {
  outb(COM1_PORT,data);
}

/*********************************************
 * Description - Output text to serial port
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo SerialPuts(i8* msg){
  for(i = 0; msg[i] != '$';i++) {
    SerialWrite(msg[i]);
  }
  Puts(msg);
}

/*********************************************
 * Description - Paint the framebuffer to VGA
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo GrFlip(){
  u8* fbloc = fb;
  u8* loc = (u8*)VGA_MEM;
  u8* dest = (u8*)VGA_MEMEND;
  while((u8*)loc != (u8*)dest){
    *loc=*fbloc;
    loc++;
    fbloc++;
  }
}

/*********************************************
 * Description - Put a pixel on the framebuffer
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo GrPutPx(i16 x, i16 y, int col){
  fb[y][x] = col;
}

/*********************************************
 * Description - Clear the framebuffer
 * given a colour
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo GrClear(int col){
  i16 x;
  i16 y;
  for(y = 0; y != VGA_RESY;y++){
    for(x = 0; x != VGA_RESX;x++){
      fb[y][x] = col;
    }
  }
}

/*********************************************
 * Description - Draw an XBM image
 * Author - Vilyaem
 * Date - May 15 2024
 * *******************************************/
static vo GrDrawXBM(u8 xbm[], i16 xpos, i16 ypos, i16 width, i16 height){
  i16 bwidth = (width + 7) / 8;
  for (int y = ypos; y != height; y++) {
    for (int x = xpos; x != width; x++) {
      u8 pix = xbm[y * bwidth + x / 8 ];
      u8 mask = 1 << (x % 8);
      if(pix & mask){
        /*VgaPutPx(x,y,FG_COL);*/
        GrPutPx(x,y,FG_COL);
      }
    }
  }
}

/*********************************************
 * Description - Main
 * Author - Vilyaem
 * Date - May 12 2024
 * *******************************************/
i16 dosmain(vo){
  Vga();
  Puts("test\n$");
  SerialPuts("Hello Serial!$");
  SetTextColour(0x04,0x0F);
  while(1){
    i16 bench;
    bench = GetOracle();

    /*Draw*/
    GrClear(BG_COL);

    GrDrawXBM(seraph_bits,50,60,seraph_width,seraph_height);

    GrFlip();


    /*Logic*/



    /*Input*/


    /* benchmarker */
    /*
    i8 oraclestr[32]; 
    oraclestr[29] = '\n';
    oraclestr[30] = '$';
    oraclestr[31] = 0;
    Int2Str(GetOracle()-bench,oraclestr);
    Puts(oraclestr);
    */

    /* frame counter */
    /*
       i8 framestr[32];
       framestr[31] = '\n';
       framestr[32] = '$';
       Int2Str(frame,framestr);
       Puts(framestr);

       frame++;
       */
  }

  return 0;
}

